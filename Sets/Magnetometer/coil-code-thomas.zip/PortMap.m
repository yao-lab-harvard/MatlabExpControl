function path=PortMap(what)

switch what
    case 'BackupFile'
        path='C:\MATLAB_Code\Data\TempDataBackup\Temp.mat';
    case 'BackupImageFile'
        path='C:\MATLAB_Code\Data\TempDataBackup\TempImage.mat';
    case 'Ctr Gate'
        path='/Dev1/PFI9';
    case 'SG ext mod'
        path='Dev1/ao2';
    case 'Ctr Trig'
        path='/Dev1/PFI13';
    case 'SG com'
        path='com11';
    case 'meas'
        path='SPCM';
    case 'gConfocal path'
        path='C:\MATLAB_Code\Sets\';
    case 'EO Drive dll'
        path='C:\Program Files\Edmund Optics\EO-Drive\EO-Drive.dll';
    case 'EO Drive h'
        path='C:\Program Files\Edmund Optics\EO-Drive\eo-drive.h';
    case 'APD in'
        path='Dev1/ai0';
    case 'Ctr in'
        path='Dev1/ctr0';
    case 'Ctr out'
        path='Dev1/ctr1';
    case 'Galvo x'
        path='Dev1/ao0';
    case 'Galvo y'
        path='Dev1/ao1';
    case 'spinapi'
        path='C:\SpinCore\SpinAPI\include\spinapi.h';
    case 'pulseblaster'
        path='C:\SpinCore\SpinAPI\include\pulseblaster.h';
    case 'dds'
        path='C:\SpinCore\SpinAPI\include\dds.h';
    case 'Data'
        path='C:\Data\';
    case 'Ctr src'
        path='/Dev1/PFI8';
    case 'Ctr gate'
        path='/Dev1/PFI9';
    case 'keithleyX'
        path= 'USB0::0x05E6::0x2200::9060029::INSTR';
    case 'keithleyY'
        path= 'USB0::0x05E6::0x2200::9104905::INSTR';
    case 'keithleyZ'
        path= 'USB0::0x05E6::0x2200::9104906::INSTR';
    case 'BNC645'
        path='USB0::0x164E::0x0FA2::TW00012797::INSTR';
    case 'scope'
        path='GPIB0::26::INSTR';
    case 'LF save'
        path='C:\Users\rt2\Documents\LightField\';
end